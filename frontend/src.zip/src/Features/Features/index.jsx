export const Features=()=>{
 
    return(
        <h1>In Features</h1>
    );

}